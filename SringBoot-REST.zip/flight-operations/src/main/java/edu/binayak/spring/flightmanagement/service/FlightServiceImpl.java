/**
 * 
 */
package edu.binayak.spring.flightmanagement.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.binayak.spring.flightmanagement.db.DBConnection;
import edu.binayak.spring.flightmanagement.dto.Flight;

/**
 * @author HP
 *
 */
@Service
public class FlightServiceImpl implements FlightService {
	
	@Autowired
	private DBConnection dbConnection;
		

	@Override
	public Flight addFlight(Flight flight) {
		// TODO Auto-generated method stub
		try {
				Connection connection =  dbConnection.getConnection();
				PreparedStatement ps = connection.prepareStatement("insert into flight values(?,?,?)");
				ps.setInt(1, flight.getFlightId());
				ps.setString(2, flight.getAirlinesName());
				ps.setInt(3, flight.getSeatCapacity());
				ps.executeUpdate();
				ps.close();
				dbConnection.coseConnection();
				
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return flight;
	}

	@Override
	public Flight updateFlight(Flight flight) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Flight> getFlights() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteFlight(int flightId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Flight getFlight(int flightId) {
		// TODO Auto-generated method stub
		Flight flight = null;
		try {
			Connection connection =  dbConnection.getConnection();
			PreparedStatement ps = connection.prepareStatement("select * from flight where flight_id=?");
			ps.setInt(1, flightId);
			ResultSet rs =  ps.executeQuery();
			if(rs.next()) {
				flight = new Flight();
				flight.setFlightId(flightId);
				flight.setAirlinesName(rs.getString(2));
				flight.setSeatCapacity(rs.getInt(3));
			}
			rs.close();
			ps.close();
			dbConnection.coseConnection();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return flight;
	}
}
