/**
 * 
 */
package edu.binayak.spring.flightmanagement.service;

import java.util.List;

import edu.binayak.spring.flightmanagement.dto.Flight;

/**
 * @author HP
 *
 */
public interface FlightService {
	public Flight addFlight(Flight flight);
	public Flight updateFlight(Flight flight);
	public List<Flight> getFlights();
	public void deleteFlight(int flightId);
	public Flight getFlight(int flightId);
}
