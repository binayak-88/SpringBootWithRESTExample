/**
 * 
 */
package edu.binayak.spring.flightmanagement.db;

import java.sql.Connection;
import java.sql.DriverManager;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

/**
 * @author HP
 *
 */
@Component
@PropertySource(value = "application.properties")
public class DBConnection {
	Connection connection = null;
	
	@Value("${db.driver.classname}")
	private  String driverClass;
	
	@Value("${db.url}")
	private String url;
	
	@Value("${db.username}")
	private String username;
	
	@Value("${db.password}")
	private String password;
	
	/*
	 * static { try { Class.forName(driverClass);
	 * System.out.println("Driver is loaded");
	 * 
	 * } catch (Exception e) { // TODO: handle exception e.printStackTrace(); } }
	 */
	
	public Connection getConnection() {
		try {
			Class.forName(driverClass);
			System.out.println("Driver is loaded");
			connection = DriverManager.getConnection(url, username, password);
			System.out.println("Connected.............");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return connection;
	}
	public void coseConnection() {
		try {
			if(connection!=null) {
				connection.close();
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}