/**
 * 
 */
package edu.binayak.spring.flightmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.binayak.spring.flightmanagement.dto.Flight;
import edu.binayak.spring.flightmanagement.exception.ErrorResponse;
import edu.binayak.spring.flightmanagement.exception.FlightAlreadyExistsException;
import edu.binayak.spring.flightmanagement.exception.FlightNotFoundException;
import edu.binayak.spring.flightmanagement.service.FlightService;

/**
 * @author HP
 *
 */
@RestController
@RequestMapping("/flight")
public class FlightController {
	
	@Autowired
	private FlightService flightService;
	
	
	@PostMapping
	public ResponseEntity<?> addFlight(@RequestBody Flight flight) {
		Flight exisitngFlight = flightService.getFlight(flight.getFlightId());
		if(exisitngFlight!=null) {
			//ErrorResponse errorResponse = new ErrorResponse();
		//	errorResponse.setErrorCode(400);
		//	errorResponse.setErrorMessage("Flight Already exists !!");
			//return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
			throw new FlightAlreadyExistsException("Flight Details already existing !!!!!!!!!");
		}
		else {
			flightService.addFlight(flight);
			return new ResponseEntity<>(flight, HttpStatus.CREATED);
			
		}
	}
	
	@GetMapping(path = "/{flightId}")
	public ResponseEntity<?> getFlight(@PathVariable Integer flightId) {
		Flight flight =  flightService.getFlight(flightId);
		if(flight!=null) {
			return new ResponseEntity<>(flight, HttpStatus.OK);
		}
		else {
			//ErrorResponse errorResponse = new ErrorResponse();
			//errorResponse.setErrorCode(400);
			//errorResponse.setErrorMessage("Flight id does not exists !!");
			//return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
			throw new FlightNotFoundException("Flight is not found in system !!!!!!!!!");
		}
	}
	
	@GetMapping
	public ResponseEntity<?> getFlights(){
		List<Flight> flights =  flightService.getFlights();
		return null;
	}
	
}
