/**
 * 
 */
package edu.binayak.spring.flightmanagement.exception;

/**
 * @author HP
 *
 */
public class FlightAlreadyExistsException extends RuntimeException {
	public FlightAlreadyExistsException(String msg) {
		super(msg);
	}
}
