/**
 * 
 */
package edu.binayak.spring.flightmanagement.exception;

/**
 * @author HP
 *
 */
public class FlightNotFoundException extends RuntimeException {
	public FlightNotFoundException(String msg) {
		super(msg);
	}
}
