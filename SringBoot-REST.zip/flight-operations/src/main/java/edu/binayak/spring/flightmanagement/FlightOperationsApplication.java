package edu.binayak.spring.flightmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightOperationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightOperationsApplication.class, args);
	}

}
